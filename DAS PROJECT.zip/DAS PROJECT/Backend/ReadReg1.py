from pymodbus.client import AsyncModbusTcpClient
from pymodbus.payload import BinaryPayloadDecoder
from pymodbus.constants import Endian
from pymodbus.exceptions import ModbusException


class TstReadReg:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(TstReadReg, cls).__new__(cls)
        return cls._instance
    
    
    def __init__(self,host,port,slave):
        self.client = AsyncModbusTcpClient(host,port)
        self.slave = slave
        
    async def connect(self):
        try:
            await self.client.connect()
            if(self.client.connected):
                print("Connected to Modbus Server")
                status = "Connected"
            
        except ModbusException:
            raise Exception("Could not connect to Modbus Server")
            status = "Could not connect to Modbus Server"
        return status
        
         
    def close(self):
        self.client.close()
        print("Disconnected from Modbus Server")
        status = "Disconnected"

    async def readHoldingReg(self) -> object:
        decoded_values = []
        responseObj = {}
        try:
            result = await self.client.read_holding_registers(0,122, slave=self.slave)
            print(len(result.registers))
            for i in range(0,len(result.registers),2):
                decoder = BinaryPayloadDecoder.fromRegisters(result.registers[i:i+2], Endian.BIG, wordorder=Endian.LITTLE)
                print("decoder"+str(decoder))
                value = decoder.decode_32bit_float()
                print("value"+str(value))
                decoded_values.append(value)
            for i in range(0,len(decoded_values)):
                if(TstReadReg.registerVariables[i] == 'NOT USED'):
                    continue
           
                responseObj[TstReadReg.registerVariables[i]] = decoded_values[i]
            
            alarmreg =  await self.client.read_coils(0, 61,slave=self.slave)
            print("Coil values:", alarmreg.bits)
            
            

            formatted_data = [{"RegName": key, "Value": value,}for key, value in responseObj.items()]
            response_to_return={"formatted_data":formatted_data,"Alarms":alarmreg.bits}

            return response_to_return
        except ModbusException as exc:
            print(f"Received ModbusException({exc}) from library")
            raise exc
        except Exception as exc:
            print(f"An exception occurred: {exc}")
            raise exc
        
        