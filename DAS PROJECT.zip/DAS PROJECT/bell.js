function handleclick(){

    alert("You have clicked on the title");
}

var heading = document.getElementById("myheading");

heading.onclick=handleclick;

function bellClicked()
{
    
    var newTab=window.open();
    
    var tableContent= `
    <table border="1">

    <tr>
    <th>Name</th>
    <th>Age</th>
    </tr>

    <tr>
    <td>Ritesh</td>
    </tr>

    </table>

    `;

    newTab.document.write(tableContent);
}