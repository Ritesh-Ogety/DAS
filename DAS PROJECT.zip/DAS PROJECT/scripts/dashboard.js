import { setGaugeValue } from "./util/gauge.js";
let D1reg=[];
let newScreen=``;
let newScreen2=``;
let a='';
axios.get('http://localhost:8000/getRegVal')
  .then(response => {
    let dashboardD1HTML='';
    console.log(response.data);
    D1reg = response.data.formatted_data;
    let firstKey = Object.keys(D1reg)[0];
    let firstValue = D1reg[firstKey];
    // console.log(firstKey);
    console.log(firstValue.RegName);
                   
        
        dashboardD1HTML+=`<div class="grid-item">
        <p>                                                     
            ${firstValue.RegName}
        </p>
        <hr>
        <div class="data">
            <div class="regvalue">
                ${parseFloat(firstValue.Value).toFixed(2)}
            </div> 
            <div class="gauge_D1">
    
                <div class="gauge__body">
    
                    <div class="gauge__fill">
    
                    </div>
    
                    <div class="gauge__cover">

                    ${parseFloat(firstValue.Value).toFixed(2)}
    
                    </div>
                    
                </div>
            </div>
        </div>
    </div>`;
    document.querySelector(".js-regvalueD1").innerHTML = dashboardD1HTML;
     let gaugeElement = document.querySelectorAll(".gauge_D1");
    console.log(gaugeElement);
    // gaugeElement.forEach((item)=>{
    // setGaugeValue(item,(D1reg["Value"][i]))/100;})
    gaugeElement.forEach((item) => {
      setGaugeValue(item, firstValue.Value / 100); // Assuming setGaugeValue function expects a value between 0 and 1.
   
  });
  
    
    newScreen = `
    <h3> D1 Register Values </h3>
    
    <table border="1">

    <tr>

    <th> Register Name </th>
    <th> Register Value</th>
    
   
    </tr>
    `;

    let count = 0;

    for (let regName in D1reg) {
        if (D1reg.hasOwnProperty(regName)) {
            let value = D1reg[regName];
    
            newScreen += `
            <tr>
                <td>${value.RegName}</td>
                <td>${value.Value.toFixed(2)}</td>
            </tr>`;
    
            count++;
            if (count === 5) {
                break; // Exit the loop after 5 iterations
            }
        }
    }
    document.querySelector(".js-D1registervalues").innerHTML=newScreen;
}

    
    );

    axios.get('http://localhost:8000/getD2RegVal')
  .then(response => {
    let dashboardD1HTML='';
    console.log(response.data);
    D1reg = response.data.formatted_data;
    let firstKey = Object.keys(D1reg)[1];
    let firstValue1 = D1reg[firstKey];
    // console.log(firstKey);
    console.log(firstValue1.RegName);
    
        
        dashboardD1HTML+=`<div class="grid-item">
        <p>                                                     
            ${firstValue1.RegName}
        </p>
        <hr>
        <div class="data">
            <div class="regvalue">
                ${parseFloat(firstValue1.Value).toFixed(2)}
            </div> 
            <div class="gauge_D2">
    
                <div class="gauge__body">
    
                    <div class="gauge__fill">
    
                    </div>
    
                    <div class="gauge__cover">

                    ${parseFloat(firstValue1.Value).toFixed(2)}
    
                    </div>
                    
                </div>
            </div>
        </div>
    </div>`;
    document.querySelector(".js-regvalueD2").innerHTML = dashboardD1HTML;
     let gaugeElement = document.querySelectorAll(".gauge_D2");
    console.log(gaugeElement);
    // gaugeElement.forEach((item)=>{
    // setGaugeValue(item,(D1reg["Value"][i]))/100;})
    gaugeElement.forEach((item1) => {
      setGaugeValue(item1, firstValue1.Value / 100); // Assuming setGaugeValue function expects a value between 0 and 1.
   
  });
  
    newScreen2 = `
    <h3> D2 Register Values </h3>
    
    <table border="1">

    <tr>

    <th> Register Name </th>
    <th> Register Value</th>
    
   
    </tr>
    `;
    console.log(D1reg);
    let count = 0;

for (let regName in D1reg) {
    if (D1reg.hasOwnProperty(regName)) {
        let value = D1reg[regName];

        newScreen2 += `
        <tr>
            <td>${value.RegName}</td>
            <td>${value.Value.toFixed(2)}</td>
        </tr>`;

        count++;
        if (count === 5) {
            break; // Exit the loop after 5 iterations
        }
    }
}

    document.querySelector(".js-D2registervalues").innerHTML=newScreen2;   
    
    });

function updateTime() {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const currentTime = `${hours}:${minutes}`;
    document.getElementById('current-time').textContent = currentTime;
}

// Update time every second
setInterval(updateTime, 1000);

// Initial call to display current time immediately
updateTime();

    


