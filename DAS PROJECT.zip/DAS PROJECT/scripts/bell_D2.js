let now = new Date();
let count=0;
let newScreen=``;
let newScreen2=``;
// Function to update the count

export function updateNotificationCount(sysAlarms,count) {

    console.log(count);
    

      for(let i=0;i<61;i++)     // Here the range ---> 0-61
        {
            if(alarmReg[i]=='NOT USED'){           // Condition: 
                continue;
            }
            if(sysAlarms[i] == true)
                count+=1;

        }

   
    //  console.log(count);
    const updated_counter = document.querySelector(".bell__notification");
    updated_counter.setAttribute("count", count.toString());
}

// export function updateNotificationCount2(count){
//     const updated_counter = document.querySelector(".bell__notification");
//     updated_counter.setAttribute("count", count.toString());
// }
// export function countSetBits(num) {
//     let count = 0;
//     while (num) {
//         count += num & 1;
//         num >>= 1;
//     }
//     return count;
// }


export function alarmInfo(registers,sysAlarms)
{
    
     newScreen = `
    <h1> User Alarms </h1>
    
    <table border="1">

    <tr>

    <th> Register Name </th>
    <th> Register Value</th>
    <th> Time Stamp </th>
    <th> Register Threshold </th>
   
    </tr>
    `;

    Object.entries(registers).forEach(([regName, value]) => {
        newScreen += `
        <tr>
            <td>${regName}</td>
            <td>${value[0]}</td>
            <td>${now.toLocaleDateString()} ${now.toLocaleTimeString()}</td>
            <td>${value[1]}</td>
        </tr>`;
    });

    newScreen+=`</table>`;
   
    
    newScreen2 = `
    <h1> System Alarms </h1>

    <table border="1">

    <tr>

    <th> Register Name </th>
    <th> Register Value</th>
    <th> Time Stamp </th>
    
   
    </tr>
    `;
    for(let i=10;i<31;i++){

    if(alarmReg[i]=='NOT USED'){
        continue;
    }
    else{
        let statusClass = sysAlarms[i] ? 'true' : 'false';
        newScreen2 += `
        <tr>
            <td>${alarmReg[i]}</td>
            <td class = "${statusClass}">${sysAlarms[i]}</td>
            <td>${now.toLocaleDateString()} ${now.toLocaleTimeString()}</td>
           
        </tr>`;
    };
    }
    newScreen2+=`</table>`;
    






    //var newTab=window.open();
    //newTab.document.write(newScreen);


    let left = (window.screen.width - 600) / 2;
    let top = (window.screen.height - 200) / 2;

// Open a popup window with the generated HTML content
let popup = window.open('', 'Alarms', 'width=600,height=200');
popup.document.write(`
    <html>
    <head>
        <title>Popup Window</title>
        <style>
            
            h1{
                color:black;
                text-align: center;
            }
           .true {
            color: green; /* Styling for true value */
                }

            .false {
            color: red; /* Styling for false value */
            }
        body{
        
            width:300px;
            color:green;
            margin:0;
            padding:0;
            justify-content:center;
            align-items:center;
            width:100%;
         
        }
        table{
    
        width:100%;
        }

        </style>
    </head>
    <body>
        
        <table>
            ${newScreen}
        </table>
        <table>
            ${newScreen2}
        </table>
    </body>
    </html>
`);
popup.document.close(); // Close the document stream to enable document.write



}



