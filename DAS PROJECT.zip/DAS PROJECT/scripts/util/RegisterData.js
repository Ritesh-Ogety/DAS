export function exportToCSV(data, filename) {
    // Extract headers from the first object
    console.log("Entered");
    const timestamp = formatCurrentDate();
    const headers = Object.keys(data[0]);
    
    // Format data into a CSV string.
    const csv = [
        ['Timestamp', timestamp], 
        headers.join(','), // Header row
        ...data.map(row => headers.map(header => row[header]).join(',')) // Data rows
    ].join('\n');
    
    // Create a Blob object.
    const blob = new Blob([csv], { type: 'text/csv' });

    // Create a URL for the Blob object.
    const url = URL.createObjectURL(blob);

    // Create a link element.
    const link = document.createElement('a');
    link.href = url;
    link.download = filename || 'data.csv';

    // Simulate click to trigger download.
    document.body.appendChild(link);
    link.click();

    // Cleanup
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

function formatCurrentDate() { 
    const date = new Date();

    //The getDate() method is converted to toString() and then converted to 2 digits. 3 --> 03.
    const day = date.getDate().toString().padStart(2, '0');

    //Here indexing is starting from 0 so Jan --> 0, i.e.., Jan --> 0+1 --> jan=1 -- > 01.
    const month = (date.getMonth() + 1).toString().padStart(2, '0');

    // Here Year is printed in the form of YY i.e.., last two digits say 2024 --> 24.
    const year = date.getFullYear().toString().slice(-2);

    // Time in hours as HH.
    const hours = date.getHours().toString().padStart(2, '0');

    // Time in minutes as MM.
    const minutes = date.getMinutes().toString().padStart(2, '0');

    // Time in seconds as SS.
    const seconds = date.getSeconds().toString().padStart(2, '0');
    
    return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
}



