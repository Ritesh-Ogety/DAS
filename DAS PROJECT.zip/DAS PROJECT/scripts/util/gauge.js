const gaugeElement=document.querySelector(".gauge");

//Method.
export function setGaugeValue(gauge,value)  // Here value range --> 0<=value<=1.
{
    if(value<0 || value>1){
            return;
        }
    // Configure Alarms.
    else if(value>=0.8) {
        gauge.querySelector(".gauge__fill").style.backgroundColor="red";
        //alert("Value is high !");
        
        }

    else if(value>=0.5){
        gauge.querySelector(".gauge__fill").style.backgroundColor="orange";
        //alert("Value is moderate.");
    }    

    else{
        gauge.querySelector(".gauge__fill").style.backgroundColor="green";   //default color:#4CAF50
    }  

    // The below line is responsible for rotation of the fill in the gauge. Say value= 0.5 --> 0.5/2=0.25 "turn"--> Full 360 degree rotation.
    gauge.querySelector(".gauge__fill").style.transform=`rotate(${value/2}turn)`;
    

    // The below line is responsible for converting the value to percntage.
    gauge.querySelector(".gauge__cover").textContent=`${Math.round(value*100)}%`;
             
}

