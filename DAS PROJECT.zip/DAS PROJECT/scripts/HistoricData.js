import { writeFile } from 'fs';


export function writedata()
{
// Data to write to file
const data = 'Hello, world!';

// Write data to file
writeFile('example.txt', data, (err) => {
  if (err) throw err;
  console.log('Data written to file');
});
}
