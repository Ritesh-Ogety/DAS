from fastapi import FastAPI
from Backend.ReadReg2 import TstReadReg
import time
from asyncio import Event
from fastapi.middleware.cors import CORSMiddleware
from Backend.ReadReg1 import TstReadReg
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)
D1Device =  TstReadReg("192.168.0.201",502,43)
@app.get("/getRegVal")
async def sendD1Data():
    response = None
    try:
        print("Got get data request from client")
        devConStat = await D1Device.connect()
         
        if(devConStat == "Connected"):
            response = await D1Device.readHoldingReg()
            print(response)
        else:
            response = devConStat
        time.sleep(1)      
    except Exception as ex:
        print("Some error occured")
    return response


D2Device =  TstReadReg("192.168.0.202",502,42)
@app.get("/getD2RegVal")
async def sendD2Data():
    response = None
    try:
        print("Got get data request from client")
        devConStat = await D2Device.connect()
         
        if(devConStat == "Connected"):
            response = await D2Device.readHoldingReg()
            print(response)
        else:
            response = devConStat
        time.sleep(1)      
    except Exception as ex:
        print("Some error occured")
    return response
